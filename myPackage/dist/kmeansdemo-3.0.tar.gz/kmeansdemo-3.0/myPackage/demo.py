def demoprint():
	kvalue=input('Enter k value:')
	print('now in the demo file',kvalue)